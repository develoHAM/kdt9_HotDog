
const get_main = (req, res) => {
    res.render('mate')
}

const post_match = (req, res) => {

}

module.exports = {
    get_main,
    post_match
}