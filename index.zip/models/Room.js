const RoomModel = (sequelize, Sequelize) => {
    return sequelize.define('room', {
        roomid: {
            type: Sequelize.DataTypes.STRING(255),
            allowNull: false,
            primaryKey: true,
        },
    })
}

module.exports = RoomModel;
