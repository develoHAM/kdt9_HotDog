const UserRoomModel = (sequelize, Sequelize) => {
    return sequelize.define('users_rooms', {
    })
}


module.exports = UserRoomModel;

