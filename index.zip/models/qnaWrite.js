const { DataTypes } = require('sequelize');

const QnaWriteModel = (sequelize) => {
    return sequelize.define('qnaWrite', {
            title: {
                type : DataTypes.STRING(127),
                allowNull: false,
            },
            writer: {
                type: DataTypes.STRING(20),
                allowNull: false,
            },
            contents: {
                type : DataTypes.TEXT,
                allowNull: false
            },
        }, {
            sequelize,
            timestamps: true,
            modelName: "qnaWrite",
            tableName: "qnaWrites",
            paranoid: false,
            charset: 'utf8mb4',
            collate: 'utf8mb4_general_ci',
        });
    }


module.exports = QnaWriteModel;