const get_hospital=(req,res)=>{
    res.render('hospital');
}

module.exports={
    get_hospital,
}