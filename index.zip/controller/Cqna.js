const  { qnaWrite } = require("../models");

// const get_qnaWrite = (req, res) => {
//     qnaWrite.findAll().then((result) => {
//         if(result.lenght > 0) {
//             res.render("qnaList", {data: result})
//         } else {
//             res.render("qnaList", {data: "hi"})
//         }
//     })
// } 

//질문 users table에서 id 끌어와서 사용할수있는지?

const qna_post = async (req, res) => {
    console.log(req.body);
    const { title, writer, contents } = req.body;
    try {
        // MySQL 쿼리를 사용하여 데이터베이스에 데이터를 삽입
        const user=await qnaWrite.create({
            title, writer, contents
        })
        if(user){
            res.json({data:true});
        }else{
            res.json({data:false});
        }
      } catch (err) {
        console.log(err);
      }
}

const qna_patch = async (req, res) => {
    console.log(req.body);
}

const qna_delete = async (req, res) => {
    console.log(req.body);
}

module.exports = {
    qna_post,
};